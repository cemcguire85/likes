var count = 0;
var numberElement = document.querySelector("#number");

function add1() {
    count++;
    numberElement.innerText = count;
}