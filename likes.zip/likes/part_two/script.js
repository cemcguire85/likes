var countOne = 0;
var neilElement = document.querySelector("#numberone");

function add1Neil() {
    countOne++;
    neilElement.innerText = countOne;
}

var countTwo = 0;
var nicholeElement = document.querySelector("#numbertwo");

function add1Nichole() {
    countTwo++;
    nicholeElement.innerText = countTwo;
}

var countThree = 0;
var jimElement = document.querySelector("#numberthree");

function add1Jim() {
    countThree++;
    jimElement.innerText = countThree;
}